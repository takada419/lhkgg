from django.contrib import admin
from .models import Genre, Film

admin.site.register(Genre)
admin.site.register(Film)

